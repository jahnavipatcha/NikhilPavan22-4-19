package com.cg.ticketcounter.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ticketcounter.*;
import com.cg.ticketcounter.model.ComposerSong;

public interface IComposerSongRepository extends JpaRepository<ComposerSong, Integer>{

}
