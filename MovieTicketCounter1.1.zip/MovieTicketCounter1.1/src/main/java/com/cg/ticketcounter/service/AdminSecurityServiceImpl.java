package com.cg.ticketcounter.service;

public class AdminSecurityServiceImpl {

}
