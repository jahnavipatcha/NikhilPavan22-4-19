package com.cg.ticketcounter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ticketcounter.*;
import com.cg.ticketcounter.model.Artist;

@Repository
public interface IMusicRepository extends JpaRepository<Artist, Integer>{
	

}
