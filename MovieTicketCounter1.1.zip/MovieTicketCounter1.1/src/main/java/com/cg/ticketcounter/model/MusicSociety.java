package com.cg.ticketcounter.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
public class MusicSociety {
	
	@Id
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })

	private int composerMusicSocietyId;
	private String composerMusicSocietyName;

	@JsonIgnore
	@OneToMany(mappedBy = "composerMusicSocietyId")
	private List<Composer> composer;

	public int getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}

	public void setComposerMusicSocietyId(int composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}

	public String getComposerMusicSocietyName() {
		return composerMusicSocietyName;
	}

	public void setComposerMusicSocietyName(String composerMusicSocietyName) {
		this.composerMusicSocietyName = composerMusicSocietyName;
	}

}
