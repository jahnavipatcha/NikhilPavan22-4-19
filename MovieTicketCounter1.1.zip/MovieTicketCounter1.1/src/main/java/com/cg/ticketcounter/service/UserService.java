package com.cg.ticketcounter.service;

import com.cg.ticketcounter.exception.TicketCounterException;
import com.cg.ticketcounter.model.Artist;
import com.cg.ticketcounter.model.User;

public interface UserService {
    void save(User userForm)throws TicketCounterException;

  //  User findByUsername(long l)throws TicketCounterException;

	User findByUsername(String name);

	User findByUsername(long l);
    
    
}
